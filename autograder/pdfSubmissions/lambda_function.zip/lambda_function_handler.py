import boto3
import json
import os

def prepare_submission(event, context):
    """
    Prepare the submission for grading
    """
    s3 = boto3.client('s3')
    
    try:
        # Download and validate submission
        bucket = event['bucket']
        key = event['key']
        submission_id = event['submission_id']
        
        # Perform any necessary preprocessing
        # For example, validate file type, size, etc.
        
        return {
            'statusCode': 200,
            'bucket': bucket,
            'key': key,
            'submission_id': submission_id,
            'status': 'PREPARED'
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'error': str(e),
            'submission_id': submission_id,
            'status': 'PREPARATION_FAILED'
        }

def run_grading(event, context):
    """
    Trigger grading process on EC2
    """
    ec2 = boto3.client('ec2')
    
    try:
        bucket = event['bucket']
        key = event['key']
        submission_id = event['submission_id']
        
        # Launch EC2 instance or trigger grading process
        response = ec2.run_instances(
            ImageId=os.environ['ami-0efc43a4067fe9a3e'],
            InstanceType='t2.medium',
            MaxCount=1,
            MinCount=1,
            UserData=f'''#!/bin/bash
# Download submission
aws s3 cp s3://{bucket}/{key} /tmp/submission

# Run grading script
docker run -v /tmp/submission:/submission autograder-image

# Upload results
aws s3 cp /tmp/results s3://gradedsubmissions/{submission_id}/
'''.encode('base64'),
            TagSpecifications=[
                {
                    'ResourceType': 'instance',
                    'Tags': [
                        {
                            'Key': 'Name',
                            'Value': f'Grading-{submission_id}'
                        }
                    ]
                }
            ]
        )
        
        return {
            'statusCode': 200,
            'instanceId': response['Instances'][0]['InstanceId'],
            'submission_id': submission_id,
            'status': 'GRADING_STARTED'
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'error': str(e),
            'submission_id': submission_id,
            'status': 'GRADING_FAILED'
        }

def check_grading_status(event, context):
    """
    Check the status of grading for a submission
    """
    s3 = boto3.client('s3')
    ec2 = boto3.client('ec2')
    
    try:
        submission_id = event['submission_id']
        
        # Check if results exist in S3
        try:
            s3.head_object(
                Bucket='gradedsubmissions', 
                Key=f'{submission_id}/results.json'
            )
            return {
                'statusCode': 200,
                'submission_id': submission_id,
                'status': 'COMPLETED'
            }
        except s3.exceptions.ClientError:
            # Check EC2 instance status
            instances = ec2.describe_instances(
                Filters=[
                    {
                        'Name': 'tag:Name',
                        'Values': [f'Grading-{submission_id}']
                    }
                ]
            )
            
            if instances['Reservations']:
                return {
                    'statusCode': 200,
                    'submission_id': submission_id,
                    'status': 'IN_PROGRESS'
                }
            else:
                return {
                    'statusCode': 200,
                    'submission_id': submission_id,
                    'status': 'FAILED'
                }
    except Exception as e:
        return {
            'statusCode': 500,
            'error': str(e),
            'submission_id': submission_id,
            'status': 'ERROR'
        }

def upload_results(event, context):
    """
    Upload grading results
    """
    s3 = boto3.client('s3')
    
    try:
        submission_id = event['submission_id']
        
        # Retrieve results from S3
        results = s3.get_object(
            Bucket='gradedsubmissions',
            Key=f'{submission_id}/results.json'
        )
        
        # You might want to do additional processing here
        # Like storing in a database, sending notifications, etc.
        
        return {
            'statusCode': 200,
            'submission_id': submission_id,
            'status': 'UPLOADED'
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'error': str(e),
            'submission_id': submission_id,
            'status': 'UPLOAD_FAILED'
        }